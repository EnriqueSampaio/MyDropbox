package server;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import rmiupload.FileTransfer;

public class Server implements FileTransfer {
    public Server() {
    }

    @Override
    public void upload(String fileName, byte[] fileBytes, int bytesCounter) throws RemoteException, FileNotFoundException, IOException {
        FileOutputStream fileOutputStream = null;
        
        File receivedFile = new File("serverFiles/" + fileName);

        if (bytesCounter == 0) {
            receivedFile.createNewFile();
            fileOutputStream = new FileOutputStream(receivedFile);
        } else {
            fileOutputStream = new FileOutputStream(receivedFile, true);
        }

        fileOutputStream.write(fileBytes);
        fileOutputStream.flush();
        fileOutputStream.close();
    }

    public static void main(String[] args) {
        try {
            Server obj = new Server();
            FileTransfer stub = (FileTransfer) UnicastRemoteObject.exportObject(obj, 0);
            Registry registry = LocateRegistry.getRegistry();
            registry.bind("FileTransfer", stub);
            System.err.println("Servidor pronto!");
        } catch (Exception e) {
            System.err.println("Exceção no servidor: " + e.toString());
            e.printStackTrace();
        }
    }
}
