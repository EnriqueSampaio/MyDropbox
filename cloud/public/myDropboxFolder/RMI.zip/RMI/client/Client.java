package client;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Scanner;
import java.util.Arrays;
import java.io.File;
import java.io.FileInputStream;
import java.util.concurrent.TimeUnit;
import java.util.Collections;

import rmiupload.FileTransfer;

public class Client {
  private Client() {};
  private static final int MAXSIZE = 1024;

  public static void main(String[] args) {
    if (args.length < 1) {
      System.out.println("Usage: java Client <host>");
      System.exit(0);      
    }

    String host = args[0];
    FileInputStream fileInputStream = null;

    try {
      Registry registry = LocateRegistry.getRegistry(host);
      FileTransfer stub = (FileTransfer) registry.lookup("FileTransfer");
      Scanner sc = new Scanner(System.in);

      while (true) {
        System.out.print("Insira o caminho do arquivo para fazer upload ou \"sair\" para encerrar a aplicação: ");
        String filePath = sc.nextLine();

        if (filePath.equals("sair")) {
          System.exit(0);
        }

        File sendFile = new File(filePath);

        if (sendFile.exists()) {
          String fileName = sendFile.getName();
          int totalBytesValue = (int) sendFile.length();
          int bytesCounter = 0;
          int pkgCounter = 0;
          int totalPackages = (int) Math.ceil((double) totalBytesValue / MAXSIZE);
          long startTime = System.currentTimeMillis();
          boolean hasError = false;

          byte[] totalBytes = new byte[totalBytesValue];

          fileInputStream = new FileInputStream(sendFile);
          fileInputStream.read(totalBytes);
          fileInputStream.close();

          int eta = pkgCounter == 0 ? 0 : (int) ((totalPackages - pkgCounter) * (System.currentTimeMillis() - startTime) / pkgCounter);
          String etaHms = pkgCounter == 0 ? "N/A" : 
          String.format("%02d:%02d:%02d", TimeUnit.MILLISECONDS.toHours(eta),
                  TimeUnit.MILLISECONDS.toMinutes(eta) % TimeUnit.HOURS.toMinutes(1),
                  TimeUnit.MILLISECONDS.toSeconds(eta) % TimeUnit.MINUTES.toSeconds(1));
          int percent = (int) Math.floor(((double) pkgCounter / totalPackages) * 100);
          
          int counterAux = pkgCounter == 0 ? 1 : pkgCounter;

          StringBuilder output = new StringBuilder(140);
          output
          .append('\r')
          .append(String.join("", Collections.nCopies(percent == 0 ? 2 : 2 - (int) Math.log10(percent), " ")))
          .append(String.format(" %d%% [", percent))
          .append(String.join("", Collections.nCopies(percent, "=")))
          .append('>')
          .append(String.join("", Collections.nCopies(100 - percent, " ")))
          .append(']')
          .append(String.join("", Collections.nCopies((int) Math.log10(totalPackages) - (int) Math.log10(counterAux), " ")))
          .append(String.format(" %d/%d, ETA: %s", pkgCounter, totalPackages, etaHms));

          System.out.print(output);

          while (bytesCounter < totalBytesValue) {
            byte[] partialBytes;
            if (totalBytesValue - bytesCounter < 1024) {
              partialBytes = Arrays.copyOfRange(totalBytes, bytesCounter, totalBytesValue);
            } else {
              partialBytes = Arrays.copyOfRange(totalBytes, bytesCounter, bytesCounter + MAXSIZE);
            }

            try {
              stub.upload(fileName, partialBytes, bytesCounter);

              pkgCounter++;
              bytesCounter+= MAXSIZE;
              
              eta = pkgCounter == 0 ? 0 : (int) ((totalPackages - pkgCounter) * (System.currentTimeMillis() - startTime) / pkgCounter);
              etaHms = pkgCounter == 0 ? "N/A" : 
              String.format("%02d:%02d:%02d", TimeUnit.MILLISECONDS.toHours(eta),
                      TimeUnit.MILLISECONDS.toMinutes(eta) % TimeUnit.HOURS.toMinutes(1),
                      TimeUnit.MILLISECONDS.toSeconds(eta) % TimeUnit.MINUTES.toSeconds(1));
              percent = (int) Math.floor(((double) pkgCounter / totalPackages) * 100);
              
              counterAux = pkgCounter == 0 ? 1 : pkgCounter;

              output = new StringBuilder(140);
               output
              .append('\r')
              .append(String.join("", Collections.nCopies(percent == 0 ? 2 : 2 - (int) Math.log10(percent), " ")))
              .append(String.format(" %d%% [", percent))
              .append(String.join("", Collections.nCopies(percent, "=")))
              .append('>')
              .append(String.join("", Collections.nCopies(100 - percent, " ")))
              .append(']')
              .append(String.join("", Collections.nCopies((int) Math.log10(totalPackages) - (int) Math.log10(counterAux), " ")))
              .append(String.format(" %d/%d, ETA: %s", pkgCounter, totalPackages, etaHms));

              System.out.print(output);
            } catch (Exception e) {
              System.out.println("Falha no envio do arquivo \"" + fileName + "\"");
              System.err.println("Exceção: " + e.toString());
              e.printStackTrace();
              hasError = true;
              break;
            }
          }

          if (!hasError) {
            System.out.println("\nArquivo \"" + fileName + "\" enviado com sucesso!");
          }
        } else {
          System.out.println("Arquivo não encontrado!");
        }
      }
    } catch (Exception e) {
      System.err.println("Exceção no client: " + e.toString());
      e.printStackTrace();
    }
  }
}