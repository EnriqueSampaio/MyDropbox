package rmiupload;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.io.FileNotFoundException;
import java.io.IOException;

public interface FileTransfer extends Remote {
    void upload(String fileName, byte[] fileBytes, int bytesCounter) throws RemoteException, FileNotFoundException, IOException;
}
